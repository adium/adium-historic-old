/*
 *  GrowlLogDefines.h
 *  Growl
 *
 *  Created by Olivier on 13/12/04.
 *  Copyright 2004 Olivier Bonnet. All rights reserved.
 *
 */
 
#define		LogPrefDomain			@"com.Growl.LogPlugin"

#define		logTypeKey				@"GrowlLog - Log type"
#define		customHistKey1			@"GrowlLog - Custom log history 1"
#define		customHistKey2			@"GrowlLog - Custom log history 2"
#define		customHistKey3			@"GrowlLog - Custom log history 3"
